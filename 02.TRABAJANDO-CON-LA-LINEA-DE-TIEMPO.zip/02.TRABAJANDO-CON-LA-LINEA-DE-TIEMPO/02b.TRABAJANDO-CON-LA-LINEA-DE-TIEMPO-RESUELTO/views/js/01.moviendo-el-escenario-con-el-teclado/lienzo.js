/*=============================================
METODOS DEL OBJETO LIENZO
=============================================*/
var lienzo = {

	canvas: function(){

		/*=============================================
		BORRAMOS CANVAS
		=============================================*/

		ctx.clearRect(0,0,canvas.width,canvas.height);

		/*=============================================
		PLANO 3
		=============================================*/

		ctx.drawImage(datos.plano3, datos.desplazamientoEscenario/5, 0, datos.plano3.naturalWidth, datos.plano3.naturalHeight);
		ctx.drawImage(datos.plano3, datos.desplazamientoEscenario/5+1000, 0, datos.plano3.naturalWidth, datos.plano3.naturalHeight);
	
		/*=============================================
		PLANO 2
		=============================================*/

		ctx.drawImage(datos.plano2, datos.desplazamientoEscenario/3.5, 0, datos.plano2.naturalWidth, datos.plano2.naturalHeight);
		ctx.drawImage(datos.plano2, datos.desplazamientoEscenario/3.5+1000, 0, datos.plano2.naturalWidth, datos.plano2.naturalHeight);

		/*=============================================
		PLANO 1
		=============================================*/	

		ctx.drawImage(datos.plano1, datos.desplazamientoEscenario/2, 0, datos.plano1.naturalWidth, datos.plano1.naturalHeight);
		ctx.drawImage(datos.plano1, datos.desplazamientoEscenario/2+1000, 0, datos.plano1.naturalWidth, datos.plano1.naturalHeight);		

		/*=============================================
		DETALLES
		=============================================*/

		for(var i = 0; i < datos.bloquesDetalles.length; i++){	

			ctx.drawImage(datos.detalles, datos.bloquesDetalles[i].x+datos.desplazamientoEscenario, datos.bloquesDetalles[i].y, datos.bloquesDetalles[i].ancho, datos.bloquesDetalles[i].alto);	

		}

		/*=============================================
		BLOQUES
		=============================================*/

		for(var i = 0; i < datos.bloques.length; i++){	

			ctx.drawImage(datos.texturaPlataforma, datos.bloques[i].x+datos.desplazamientoEscenario, datos.bloques[i].y, datos.bloques[i].ancho, datos.bloques[i].alto);

		}

		/*=============================================
		JUGADOR
		=============================================*/

		ctx.drawImage(datos.imgJugador, 0, 0, 100, 100, datos.jugador_x, datos.jugador_y, datos.jugador_ancho, datos.jugador_alto);

		/*=============================================
		PLANO 0
		=============================================*/

		ctx.drawImage(datos.plano0, datos.desplazamientoEscenario/1.5, 0, datos.plano0.naturalWidth, datos.plano0.naturalHeight);
		ctx.drawImage(datos.plano0, datos.desplazamientoEscenario/1.5+1000, 0, datos.plano0.naturalWidth, datos.plano0.naturalHeight);		

	}

}
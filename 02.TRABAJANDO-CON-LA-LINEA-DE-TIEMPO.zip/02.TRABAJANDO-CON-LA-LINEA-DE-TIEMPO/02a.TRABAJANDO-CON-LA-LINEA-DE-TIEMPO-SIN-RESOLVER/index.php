<?php

require_once "controllers/template.php";
require_once "controllers/usuarios.php";

require_once "models/usuarios.php";

$template = new TemplateController();
$template -> template();
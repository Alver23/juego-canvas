<!--=====================================
INGRESO
======================================-->

<div id="ingreso">
	
	<div id="ingresoFacebook">
		
		<img src="views/img/intro/facebook.svg">
		<button onclick="inicio.iniciar()">Ingresar con Facebook</button>

	</div>

</div>
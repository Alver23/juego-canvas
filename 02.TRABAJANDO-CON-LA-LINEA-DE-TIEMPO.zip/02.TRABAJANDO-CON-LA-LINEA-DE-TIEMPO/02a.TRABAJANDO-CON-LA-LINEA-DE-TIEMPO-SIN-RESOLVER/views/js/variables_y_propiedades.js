/*=============================================
VARIABLES DEL CANVAS
=============================================*/
var canvas;
var ctx;

/*=============================================
PROPIEDADES DEL OBJETO DATOS
=============================================*/

var datos = {
	nivel: null,
	plano3: null,
	plano2: null,
	plano1: null,
	plano0: null,
	texturaPlataforma: null,
	bloques:[],
	imgJugador:null,
	jugador_x:70,
	jugador_y:200,
	jugador_ancho:40,
	jugador_alto:40,
	detalles: null,
	bloquesDetalles:[]

}